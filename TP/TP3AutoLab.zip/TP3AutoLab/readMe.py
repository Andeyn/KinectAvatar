This game is called "The Last Airbender: Kinect ShowDown". 
This is essentially a “Streetfighter” fighting game of The Last Airbender that the user can play/control with the Kinect against an AI.

This project should be run in Python 3.6, in an editor such as Pyzo, and have all the image files in the same directory.

To play, you will need to install PyKinect2, the Kinect SDK, a Microsoft Kinect and Pygame.

This file has a pygame version you can use the keyboard to play. Keys "Space, enter, up, down, right, and left" are used.
To control the game with the Kinect, use the "Lasso" to skip ahead to the actual game.
To play the game, you must block with arms up, shoot with a "lasso" of hands, and hands together to charge.

